// import jQuery from "jquery"

// (function($) {
//   $(function() {
//     // $('.sidenav').sidenav()
//     $('.sidenav').hide()
//   })
// })(jQuery)